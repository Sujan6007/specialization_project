export class User{
   name:string='';
   emailid:string='';
   password:string='';
   mobilenumber:number=0;
   
}